#Muestreo aleatorio simple#
##Generar números aleatorios para una muestra de 61 personas en una 
#población de 73 alumnas/os del 5to semestre de la LEP BENV. 
##Con una confiabilidad del 95% y 5% de error.
#Lo cuál fue verificado en el siguiente link 
#<https://www.macorr.com/sample-size-calculator.htm>#
  ------------------------------
  #X= del 1 al 73, que corresponde a la población-
 # Side será =61, que corresponde a el tamaño de la muestra.
#Replance= significa eliminare ese número o no del juego. True se repiten
  #personas y false no lo hace.
--------------------------------
sample(1:73, 61, replace=FALSE)
 
sample(1:73, 61, replace=FALSE)

 sample(1:73, 61, replace=TRUE)
-------------------------------------
  ##Ejercicios de muestreo aleatorio simple
 
 #1.1- Calcula el tamaño de muestra para una poblacion de 
 #83 alumnas y alumnos que se encuentran en primer grado
 #de la Licenciatura en Educación Primaria de la BENV.
# **Procedimiento:**
  # a)Calcular el número de muestra
 # El cual es de 68 alumnas/alumnos
  
 # 1.2.- Una vez que obtengas el tamaño de la muestra, 
  #selecciona el número de lista de las personas que formaran
 # parte de la muestra.
  #**Procedimiento:**#
   # b)Se abre un chonk
 -----------------
   sample(1:83,68, replace = FALSE)
 ------------------
  ##1.3.- Crea un vector llamado muestra con los números de 
 #lista de las personas que forman parte de la muestra.
 #Procedimiento:
   #Forma larga copiar y pegar poniendo las comas a cada uno 
   muestra<-c(29, 21, 32, 61, 18, 83,  5, 15, 70, 45, 57,  3, 82, 27, 40, 42, 
              68, 
              58, 
              22,  2, 73, 38, 54, 77, 66,  8, 46, 11, 13, 49,
              52, 51, 14, 31,  4, 28, 16, 23, 30, 76, 71, 80, 74, 60, 35, 37,
              48, 19, 81, 50, 
              36,  9, 72, 69, 25, 62, 24, 59, 55, 75,
              12, 41, 65, 47, 78, 20, 67,  7)
 ---------
   Forma corta y profesional
 -----------------
   muestra2<-sample(1:83, 68, replace=FALSE)
 muestra2
 ------------
   # Mustreo estratificado
   #a)Separar los estratos de alumnos 
  #Matricula de 328 alumnos 
  #Primer año: 47, 
  #segundo año: 58, 
  #tercer año: 51, 
  #cuarto año: 51, 
  #quinto año: 61 y 
  #sexto año: 60
  #b) Calcular la muestra de cada grado
  #Primero_ Muestra: 42
 
 sample(1:47, 42, replace=FALSE)
 
 vector1<-sample(1:47, 42, replace=FALSE)
 vector1
 
 sample(1:58, 51, replace=FALSE)
 
 Vector2<-sample(1:58, 51, replace=FALSE)
 Vector2
 
 sample(1:51, 45, replace=FALSE)
 
 Vector3<-sample(1:51, 45, replace=FALSE)
 Vector3
 sample(1:51, 45, replace=FALSE)
 
 Vector4<-sample(1:51, 45, replace=FALSE)
 Vector4
 sample(1:61, 53, replace=FALSE)
 
 Vector5<-sample(1:61, 53, replace=FALSE)
 Vector5
 sample(1:60, 52, replace=FALSE)
 Vector6<-sample(1:60, 52, replace=FALSE)
 Vector6